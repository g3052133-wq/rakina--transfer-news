// Netlify serverless function for API-Football transfer records.
// Store API_FOOTBALL_KEY in Netlify's environment-variable settings. Never hard-code it here.
const TEAMS = [
  {id: 33, name: "Manchester United"}, {id: 50, name: "Manchester City"},
  {id: 40, name: "Liverpool"}, {id: 42, name: "Arsenal"}, {id: 49, name: "Chelsea"},
  {id: 47, name: "Tottenham Hotspur"}, {id: 541, name: "Real Madrid"}, {id: 529, name: "Barcelona"},
  {id: 505, name: "Inter"}, {id: 496, name: "Juventus"}, {id: 489, name: "AC Milan"},
  {id: 157, name: "Bayern Munich"}, {id: 165, name: "Borussia Dortmund"},
  {id: 85, name: "Paris Saint-Germain"}, {id: 81, name: "Marseille"},
  {id: 194, name: "Atlético Madrid"}, {id: 128, name: "Flamengo"}, {id: 239, name: "Al Ahly"}
];
exports.handler = async function(event) {
  const key = process.env.API_FOOTBALL_KEY;
  if (!key) return { statusCode: 503, headers: {"Content-Type":"application/json","Cache-Control":"no-store"}, body: JSON.stringify({error:"API_FOOTBALL_KEY is not configured in Netlify environment variables."}) };
  try {
    // API-Football's transfers endpoint requires a player or team ID; query a limited set of clubs
    // so the free tier's 100 requests/day is not exhausted by each page visit.
    const chosen = TEAMS.slice(0, 12);
    const responses = await Promise.all(chosen.map(async team => {
      const url = `https://v3.football.api-sports.io/transfers?team=${team.id}`;
      const r = await fetch(url, { headers: {"x-apisports-key": key} });
      if (!r.ok) return [];
      const data = await r.json();
      return (data.response || []).map(row => {
        const tr = (row.transfers || [])[0] || {};
        return {
          player: row.player?.name || "Player",
          from: tr.teams?.out?.name || "Unknown club",
          to: tr.teams?.in?.name || team.name,
          date: tr.date || "",
          type: tr.type || "",
          fee: tr.type || "Not reported",
          team: team.name
        };
      });
    }));
    const all = responses.flat();
    const unique = new Map();
    for (const t of all) {
      const k = `${t.player}|${t.from}|${t.to}|${t.date}`;
      if (!unique.has(k)) unique.set(k, t);
    }
    const transfers = [...unique.values()].sort((a,b) => (b.date || "").localeCompare(a.date || "")).slice(0, 36);
    return {
      statusCode: 200,
      headers: {"Content-Type":"application/json","Cache-Control":"public, max-age=1800, s-maxage=1800"},
      body: JSON.stringify({source:"API-Football", count:transfers.length, transfers, message: transfers.length ? "" : "No records returned from the selected clubs."})
    };
  } catch (err) {
    return {statusCode:502,headers:{"Content-Type":"application/json","Cache-Control":"no-store"},body:JSON.stringify({error:"Unable to reach the football data service. Try again later."})};
  }
};
